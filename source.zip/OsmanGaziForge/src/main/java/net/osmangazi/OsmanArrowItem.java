package net.osmangazi;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class OsmanArrowItem extends ArrowItem {
    public OsmanArrowItem(Properties p) { super(p); }

    @Override
    public AbstractArrow createArrow(Level level, ItemStack stack, LivingEntity shooter) {
        Arrow a = new Arrow(level, shooter);
        a.setBaseDamage(2.6D);
        return a;
    }
}
