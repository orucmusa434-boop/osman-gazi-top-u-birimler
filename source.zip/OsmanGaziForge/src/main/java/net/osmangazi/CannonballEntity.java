package net.osmangazi;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

/** Top / el topu güllesi: çarptığı yerde patlar, bloklara zarar vermez, dostlara zarar vermez. */
public class CannonballEntity extends ThrowableItemProjectile {
    private float damage = 8.0F;

    public CannonballEntity(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public CannonballEntity(Level level, LivingEntity shooter) {
        super(ModEntities.CANNONBALL.get(), shooter, level);
    }

    public void setDamage(float d) { this.damage = d; }

    @Override
    protected Item getDefaultItem() { return ModItems.GULLE.get(); }

    @Override
    protected float getGravity() { return 0.04F; }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide) return;
        Entity owner = getOwner();
        double r = 3.0D;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r), x -> x.isAlive() && !isFriendly(owner, x))) {
            double d = e.distanceTo(this);
            if (d > r) continue;
            float amount = (float) (damage * (1.0D - 0.5D * d / r));
            e.hurt(damageSources().explosion(this, owner), amount);
        }
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY(), getZ(), 12, 0.4, 0.4, 0.4, 0.02);
        }
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.NEUTRAL, 1.2F, 1.0F);
        discard();
    }

    private static boolean isFriendly(Entity owner, LivingEntity e) {
        if (e == owner) return true;
        if (owner instanceof Player p && e instanceof OsmanUnit u && u.isTame() && u.isOwnedBy(p)) return true;
        if (owner instanceof OsmanUnit o) {
            if (e instanceof OsmanUnit u && o.isAlly(u)) return true;
            if (e instanceof Player p && o.isTame() && o.isOwnedBy(p)) return true;
        }
        return false;
    }
}
