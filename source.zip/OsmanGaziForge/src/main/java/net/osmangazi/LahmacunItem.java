package net.osmangazi;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Lahmacun: 8 açlık çubuğu doldurur, ayrıca 7 can (14 HP) iyileştirir. */
public class LahmacunItem extends Item {
    public LahmacunItem(Properties p) { super(p); }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack r = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide) entity.heal(14.0F);
        return r;
    }
}
