package net.osmangazi.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.osmangazi.OsmanGaziMod;
import net.osmangazi.OsmanUnit;
import net.osmangazi.UnitDef;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class OsmanRenderer extends HumanoidMobRenderer<OsmanUnit, PlayerModel<OsmanUnit>> {
    private final ResourceLocation texture;
    private final float scale;

    public OsmanRenderer(EntityRendererProvider.Context ctx, UnitDef def) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.texture = new ResourceLocation(OsmanGaziMod.MODID, "textures/entity/" + def.id() + ".png");
        this.scale = def.scale();
        PlayerModel<OsmanUnit> m = this.getModel();
        m.rightPants.visible = false;   // bacak katmanı kullanılmıyor (kazma/silah dokuları orada duruyor)
        m.leftPants.visible = false;
    }

    @Override
    public ResourceLocation getTextureLocation(OsmanUnit e) { return texture; }

    @Override
    protected void scale(OsmanUnit e, PoseStack ps, float partial) { ps.scale(scale, scale, scale); }
}
